export const categories = [
    {
        slug: "cafe",
        name: "Café"
      },
      {
        slug: "hamburguesa",
        name: "Hamburguesas"
      },
      {
        slug: "pizza",
        name: "Pizzas"
      },
      {
        slug: "dona",
        name: "Donas"
      },
      {
        slug: "pastel",
        name: "Pasteles"
      },
      {
        slug: "galletas",
        name: "Galletas"
      }
]